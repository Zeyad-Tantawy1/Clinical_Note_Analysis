# Clinical_Note_Analysis
using NLP

حسبي الله ونعم الوكيل
