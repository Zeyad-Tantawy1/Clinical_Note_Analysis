<footer class="footer">
        <div class="center footer-content">
            <p>&copy; 2024 Medical Discussions Forum. All rights reserved.</p>
            <p>Contact Us: <a href="mailto:info@medicalforum.com">info@medicalforum.com</a></p>
            <div class="center footer-socials">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </footer>
</body>